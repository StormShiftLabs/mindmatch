import React, { useState } from 'react';
import { MicIcon, SearchIcon } from 'lucide-react';
import { VoiceInput } from './VoiceInput';
export function MoodInput({
  value,
  onChange,
  onAnalyze
}) {
  const [isListening, setIsListening] = useState(false);
  const handleVoiceResult = transcript => {
    onChange(transcript);
    setIsListening(false);
  };
  return <div className="bg-gray-900/60 backdrop-blur-md rounded-xl p-6 shadow-lg border border-gray-800 hover:border-gray-700 transition-colors">
      <h2 className="text-xl md:text-2xl font-semibold mb-4">
        How are you feeling today?
      </h2>
      <div className="relative">
        <textarea value={value} onChange={e => onChange(e.target.value)} placeholder="Write about your feelings, thoughts, or experiences..." className="w-full bg-gray-800/70 text-white placeholder-gray-400 rounded-lg p-4 min-h-[150px] focus:outline-none focus:ring-2 focus:ring-teal-500/50 transition-all border border-gray-700" />
        <VoiceInput isListening={isListening} onResult={handleVoiceResult} onListeningChange={setIsListening}>
          <button className={`absolute bottom-4 right-4 p-2 rounded-full ${isListening ? 'bg-red-500 animate-pulse' : 'bg-gray-700 hover:bg-gray-600'} transition-all`} aria-label="Voice input">
            <MicIcon size={18} />
          </button>
        </VoiceInput>
      </div>
      <button onClick={onAnalyze} disabled={!value.trim()} className={`mt-4 w-full md:w-auto px-6 py-3 rounded-lg font-medium flex items-center justify-center gap-2 transition-all ${value.trim() ? 'bg-gradient-to-r from-teal-500 to-blue-500 hover:opacity-90 shadow-lg hover:shadow-teal-500/20' : 'bg-gray-700 cursor-not-allowed opacity-50'}`}>
        <SearchIcon size={18} />
        🔍 Analyze My Mood
      </button>
    </div>;
}