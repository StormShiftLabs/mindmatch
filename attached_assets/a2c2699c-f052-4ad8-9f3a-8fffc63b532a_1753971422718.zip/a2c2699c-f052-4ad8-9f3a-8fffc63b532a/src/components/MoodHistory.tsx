import React from 'react';
import { ArrowLeftIcon, TrashIcon, BarChart2Icon } from 'lucide-react';
import { MoodChart } from './MoodChart';
export function MoodHistory({
  entries,
  onBack
}) {
  const formatDate = date => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  };
  return <div className="space-y-8">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-300 hover:text-white transition-colors">
          <ArrowLeftIcon size={18} />
          Back
        </button>
        <h2 className="text-xl md:text-2xl font-semibold">Your Mood History</h2>
      </div>
      {entries.length > 0 ? <>
          <div className="bg-gray-900/60 backdrop-blur-md rounded-xl p-6 shadow-lg border border-gray-800">
            <div className="flex items-center gap-2 mb-4">
              <BarChart2Icon size={20} className="text-teal-500" />
              <h3 className="text-lg font-medium">Mood Trends</h3>
            </div>
            <MoodChart entries={entries} />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {entries.map(entry => <div key={entry.id} className="bg-gray-900/60 backdrop-blur-md rounded-xl p-5 shadow-lg border border-gray-800 hover:border-gray-700 transition-all group">
                <div className="flex justify-between items-start mb-3">
                  <span className="text-gray-400 text-sm">
                    {formatDate(entry.date)}
                  </span>
                  <button className="text-gray-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity">
                    <TrashIcon size={16} />
                  </button>
                </div>
                <div className="mb-3">
                  <span className="inline-block px-3 py-1 rounded-full text-sm bg-gray-800/80 border border-gray-700 mb-2">
                    {entry.mood}
                  </span>
                  {entry.note && <p className="text-gray-300">{entry.note}</p>}
                </div>
                <div className="border-t border-gray-800 pt-3 mt-3">
                  <p className="text-sm text-gray-400 italic">
                    "{entry.quote.text}"
                  </p>
                </div>
              </div>)}
          </div>
        </> : <div className="bg-gray-900/60 backdrop-blur-md rounded-xl p-8 shadow-lg border border-gray-800 text-center">
          <p className="text-gray-400">
            No entries yet. Start journaling to see your mood history.
          </p>
        </div>}
    </div>;
}