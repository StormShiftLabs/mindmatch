import React, { useEffect, useState } from 'react';
import { CheckCircleIcon } from 'lucide-react';
export function Toast({
  message
}) {
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false);
    }, 3000);
    return () => clearTimeout(timer);
  }, []);
  if (!visible) return null;
  return <div className="fixed bottom-6 right-6 bg-gray-900 rounded-lg py-3 px-4 shadow-xl border border-gray-800 flex items-center gap-3 animate-slideUp z-50">
      <CheckCircleIcon size={20} className="text-teal-500" />
      <span>{message}</span>
    </div>;
}