import React, { useEffect } from 'react';
export function Modal({
  children,
  onClose
}) {
  useEffect(() => {
    // Prevent scrolling when modal is open
    document.body.style.overflow = 'hidden';
    // Handle escape key press
    const handleEscape = e => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleEscape);
    return () => {
      document.body.style.overflow = 'auto';
      window.removeEventListener('keydown', handleEscape);
    };
  }, [onClose]);
  return <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fadeIn">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose}></div>
      <div className="bg-gray-900 rounded-xl p-6 w-full max-w-md shadow-xl border border-gray-800 z-10 animate-slideIn" onClick={e => e.stopPropagation()}>
        {children}
      </div>
    </div>;
}