import React, { useState } from 'react';
export function FloatingActionButton({
  onClick,
  icon,
  label
}) {
  const [showLabel, setShowLabel] = useState(false);
  return <div className="fixed bottom-6 right-6 z-30">
      <button onClick={onClick} onMouseEnter={() => setShowLabel(true)} onMouseLeave={() => setShowLabel(false)} className="bg-gradient-to-r from-teal-500 to-blue-500 w-14 h-14 rounded-full flex items-center justify-center shadow-lg hover:shadow-teal-500/20 transition-all relative">
        {icon}
        {showLabel && <span className="absolute right-full mr-3 whitespace-nowrap bg-gray-900 px-3 py-1 rounded text-sm animate-fadeIn">
            {label}
          </span>}
      </button>
    </div>;
}