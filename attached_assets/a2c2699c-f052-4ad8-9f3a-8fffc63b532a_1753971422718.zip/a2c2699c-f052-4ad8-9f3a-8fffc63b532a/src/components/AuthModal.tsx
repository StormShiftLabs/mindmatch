import React, { useState } from 'react';
import { XIcon, UserIcon, LockIcon } from 'lucide-react';
import { Modal } from './ui/Modal';
export function AuthModal({
  onClose,
  onLogin
}) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const handleSubmit = e => {
    e.preventDefault();
    // In a real app, you would validate and authenticate
    onLogin();
  };
  return <Modal onClose={onClose}>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">
          {isLogin ? 'Sign In' : 'Create Account'}
        </h2>
        <button onClick={onClose} className="p-2 hover:bg-gray-800 rounded-full transition-colors">
          <XIcon size={18} />
        </button>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm text-gray-400 mb-1">Email</label>
          <div className="relative">
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full bg-gray-800/50 text-white pl-10 pr-3 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500/50 transition-all border border-gray-700" placeholder="Enter your email" required />
            <UserIcon size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
          </div>
        </div>
        <div>
          <label className="block text-sm text-gray-400 mb-1">Password</label>
          <div className="relative">
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full bg-gray-800/50 text-white pl-10 pr-3 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500/50 transition-all border border-gray-700" placeholder="Enter your password" required />
            <LockIcon size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
          </div>
        </div>
        <button type="submit" className="w-full bg-gradient-to-r from-teal-500 to-blue-500 px-6 py-3 rounded-lg font-medium hover:opacity-90 transition-all shadow-lg hover:shadow-teal-500/20 mt-6">
          {isLogin ? 'Sign In' : 'Create Account'}
        </button>
      </form>
      <div className="mt-6 text-center text-sm text-gray-400">
        {isLogin ? "Don't have an account? " : 'Already have an account? '}
        <button onClick={() => setIsLogin(!isLogin)} className="text-teal-400 hover:text-teal-300 transition-colors">
          {isLogin ? 'Sign Up' : 'Sign In'}
        </button>
      </div>
    </Modal>;
}