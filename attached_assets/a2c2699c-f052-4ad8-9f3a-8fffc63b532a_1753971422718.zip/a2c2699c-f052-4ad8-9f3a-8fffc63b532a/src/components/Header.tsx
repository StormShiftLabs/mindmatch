import React from 'react';
import { LogOutIcon, LogInIcon } from 'lucide-react';
export function Header({
  isLoggedIn,
  onLoginClick,
  onLogoutClick
}) {
  return <header className="sticky top-0 bg-[#121212]/80 backdrop-blur-md border-b border-gray-800 z-10">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between max-w-4xl">
        <div className="flex items-center">
          <h1 className="text-xl md:text-2xl font-bold bg-gradient-to-r from-teal-400 to-blue-500 bg-clip-text text-transparent">
            MindMatch <span className="ml-1">🧘‍♀️</span>
          </h1>
        </div>
        <div>
          {isLoggedIn ? <button onClick={onLogoutClick} className="flex items-center gap-2 text-sm text-gray-300 hover:text-white transition-colors">
              <span className="hidden md:inline">Sign Out</span>
              <LogOutIcon size={18} />
            </button> : <button onClick={onLoginClick} className="flex items-center gap-2 text-sm text-gray-300 hover:text-white transition-colors">
              <span className="hidden md:inline">Sign In</span>
              <LogInIcon size={18} />
            </button>}
        </div>
      </div>
    </header>;
}