import React, { useState } from 'react';
import { RefreshCwIcon, CheckIcon, CalendarIcon } from 'lucide-react';
export function MoodAnalysis({
  analysis,
  onLogEntry,
  onViewHistory
}) {
  const [quote, setQuote] = useState(analysis.quote);
  const getMoodColor = mood => {
    if (mood.includes('Happy') || mood.includes('Calm')) return 'bg-green-500/20 text-green-300 border-green-500/30';
    if (mood.includes('Sad') || mood.includes('Anxious')) return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
    if (mood.includes('Frustrated') || mood.includes('Angry')) return 'bg-red-500/20 text-red-300 border-red-500/30';
    return 'bg-purple-500/20 text-purple-300 border-purple-500/30';
  };
  const getNewQuote = () => {
    const quotes = [{
      text: 'Every moment is a fresh beginning.',
      author: 'T.S. Eliot'
    }, {
      text: "Nothing is impossible. The word itself says 'I'm possible!'",
      author: 'Audrey Hepburn'
    }, {
      text: 'The only way to do great work is to love what you do.',
      author: 'Steve Jobs'
    }, {
      text: "Believe you can and you're halfway there.",
      author: 'Theodore Roosevelt'
    }, {
      text: 'It does not matter how slowly you go as long as you do not stop.',
      author: 'Confucius'
    }];
    const newQuote = quotes[Math.floor(Math.random() * quotes.length)];
    setQuote(newQuote);
  };
  return <div className="space-y-6 animate-fadeIn">
      <div className="bg-gray-900/60 backdrop-blur-md rounded-xl p-6 shadow-lg border border-gray-800">
        <h3 className="text-lg font-medium text-gray-300 mb-3">
          Detected Mood
        </h3>
        <div className={`inline-block px-4 py-2 rounded-full border ${getMoodColor(analysis.mood)}`}>
          <span className="text-lg font-medium">{analysis.mood}</span>
        </div>
      </div>
      <div className="bg-gray-900/60 backdrop-blur-md rounded-xl p-6 shadow-lg border border-gray-800 relative overflow-hidden group">
        <div className="absolute inset-0 bg-gradient-to-r from-teal-500/10 to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
        <h3 className="text-lg font-medium text-gray-300 mb-4">Your Quote</h3>
        <blockquote className="border-l-4 border-teal-500 pl-4 italic">
          <p className="text-xl text-white">{quote.text}</p>
          <footer className="mt-2 text-gray-400">— {quote.author}</footer>
        </blockquote>
        <button onClick={getNewQuote} className="mt-4 flex items-center gap-2 text-teal-400 hover:text-teal-300 transition-colors">
          <RefreshCwIcon size={16} />
          🔁 Show Another Quote
        </button>
      </div>
      <div className="flex flex-col sm:flex-row gap-4">
        <button onClick={onLogEntry} className="flex-1 bg-gradient-to-r from-teal-500 to-blue-500 px-6 py-3 rounded-lg font-medium flex items-center justify-center gap-2 hover:opacity-90 transition-all shadow-lg hover:shadow-teal-500/20">
          <CheckIcon size={18} />✅ Log Entry
        </button>
        <button onClick={onViewHistory} className="flex-1 bg-gray-800 border border-gray-700 px-6 py-3 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-gray-700 transition-all">
          <CalendarIcon size={18} />
          📅 View Mood History
        </button>
      </div>
    </div>;
}