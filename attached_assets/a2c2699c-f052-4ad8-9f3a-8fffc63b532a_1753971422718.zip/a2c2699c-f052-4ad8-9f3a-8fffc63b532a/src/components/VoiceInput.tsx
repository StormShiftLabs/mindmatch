import React, { useEffect } from 'react';
export function VoiceInput({
  children,
  isListening,
  onResult,
  onListeningChange
}) {
  useEffect(() => {
    if (!isListening) return;
    // Check if browser supports speech recognition
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert("Your browser doesn't support speech recognition. Try Chrome or Edge.");
      onListeningChange(false);
      return;
    }
    // Initialize speech recognition
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.onresult = event => {
      const transcript = event.results[0][0].transcript;
      onResult(transcript);
    };
    recognition.onerror = event => {
      console.error('Speech recognition error', event.error);
      onListeningChange(false);
    };
    recognition.onend = () => {
      onListeningChange(false);
    };
    recognition.start();
    return () => {
      recognition.stop();
    };
  }, [isListening, onResult, onListeningChange]);
  return <div onClick={() => onListeningChange(!isListening)}>{children}</div>;
}