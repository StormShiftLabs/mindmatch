import React, { useState } from 'react';
import { XIcon, SaveIcon } from 'lucide-react';
import { Modal } from './ui/Modal';
import { Toast } from './ui/Toast';
export function LogEntryModal({
  mood,
  date,
  onClose,
  onSave
}) {
  const [note, setNote] = useState('');
  const [showToast, setShowToast] = useState(false);
  const handleSave = () => {
    setShowToast(true);
    setTimeout(() => {
      onSave(note);
    }, 1500);
  };
  const formattedDate = new Intl.DateTimeFormat('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  }).format(date);
  return <>
      <Modal onClose={onClose}>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">Log Your Entry</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-800 rounded-full transition-colors">
            <XIcon size={18} />
          </button>
        </div>
        <div className="space-y-4 mb-6">
          <div>
            <label className="block text-sm text-gray-400 mb-1">Date</label>
            <div className="bg-gray-800/50 rounded-lg p-3 border border-gray-700">
              {formattedDate}
            </div>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Mood</label>
            <div className="bg-gray-800/50 rounded-lg p-3 border border-gray-700">
              {mood}
            </div>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">
              Notes (optional)
            </label>
            <textarea value={note} onChange={e => setNote(e.target.value)} placeholder="Add any thoughts or reflections..." className="w-full bg-gray-800/50 text-white placeholder-gray-500 rounded-lg p-3 min-h-[100px] focus:outline-none focus:ring-2 focus:ring-teal-500/50 transition-all border border-gray-700" />
          </div>
        </div>
        <button onClick={handleSave} className="w-full bg-gradient-to-r from-teal-500 to-blue-500 px-6 py-3 rounded-lg font-medium flex items-center justify-center gap-2 hover:opacity-90 transition-all shadow-lg hover:shadow-teal-500/20">
          <SaveIcon size={18} />
          💾 Save Entry
        </button>
      </Modal>
      {showToast && <Toast message="Entry Saved!" />}
    </>;
}