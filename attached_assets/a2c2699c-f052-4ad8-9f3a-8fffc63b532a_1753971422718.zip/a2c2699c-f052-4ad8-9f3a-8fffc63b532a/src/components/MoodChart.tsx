import React from 'react';
export function MoodChart({
  entries
}) {
  // This is a simplified chart implementation
  // In a real app, you would use a library like recharts
  if (entries.length === 0) return null;
  const getEmoji = mood => {
    if (mood.includes('Happy')) return '😊';
    if (mood.includes('Sad')) return '😔';
    if (mood.includes('Anxious')) return '😞';
    if (mood.includes('Frustrated')) return '😠';
    if (mood.includes('Calm')) return '😌';
    return '🤔';
  };
  const getSentimentScore = mood => {
    if (mood.includes('Happy') || mood.includes('Calm')) return 8;
    if (mood.includes('Confused')) return 5;
    if (mood.includes('Sad')) return 3;
    if (mood.includes('Anxious') || mood.includes('Frustrated')) return 2;
    return 5;
  };
  // Get the last 7 entries or fewer
  const chartEntries = entries.slice(0, 7).reverse();
  const maxScore = 10;
  return <div className="h-[200px] w-full flex items-end justify-between gap-2 pt-6 pb-2">
      {chartEntries.map(entry => {
      const score = entry.sentimentScore || getSentimentScore(entry.mood);
      const heightPercent = score / maxScore * 100;
      return <div key={entry.id} className="flex flex-col items-center flex-1">
            <div className="w-full bg-gradient-to-t from-teal-500/40 to-blue-500/40 rounded-t-md relative group cursor-pointer" style={{
          height: `${heightPercent}%`
        }}>
              <span className="absolute -top-8 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-gray-800 px-2 py-1 rounded text-xs">
                {entry.mood}
              </span>
            </div>
            <div className="mt-2 text-center">
              <div className="text-lg">{getEmoji(entry.mood)}</div>
              <div className="text-xs text-gray-500">
                {new Date(entry.date).toLocaleDateString(undefined, {
              day: 'numeric',
              month: 'short'
            })}
              </div>
            </div>
          </div>;
    })}
    </div>;
}