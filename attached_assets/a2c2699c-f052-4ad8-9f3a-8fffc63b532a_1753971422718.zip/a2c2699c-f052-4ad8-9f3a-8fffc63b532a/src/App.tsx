import React, { useState } from 'react';
import { Header } from './components/Header';
import { MoodInput } from './components/MoodInput';
import { MoodAnalysis } from './components/MoodAnalysis';
import { LogEntryModal } from './components/LogEntryModal';
import { MoodHistory } from './components/MoodHistory';
import { AuthModal } from './components/AuthModal';
import { FloatingActionButton } from './components/ui/FloatingActionButton';
import { PlusIcon } from 'lucide-react';
export function App() {
  const [showAuth, setShowAuth] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userInput, setUserInput] = useState('');
  const [moodAnalysis, setMoodAnalysis] = useState(null);
  const [showLogEntry, setShowLogEntry] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [entries, setEntries] = useState([]);
  const handleAnalyze = () => {
    if (!userInput.trim()) return;
    // Mock AI analysis - in a real app this would call an API
    const moods = ['😊 Happy', '😔 Sad', '😠 Frustrated', '😞 Anxious', '😌 Calm', '🤔 Confused'];
    const randomMood = moods[Math.floor(Math.random() * moods.length)];
    const quotes = [{
      text: 'You are braver than you believe, stronger than you seem, and smarter than you think.',
      author: 'A.A. Milne'
    }, {
      text: 'The only way to do great work is to love what you do.',
      author: 'Steve Jobs'
    }, {
      text: 'Life is 10% what happens to you and 90% how you react to it.',
      author: 'Charles R. Swindoll'
    }, {
      text: 'Happiness is not something ready-made. It comes from your own actions.',
      author: 'Dalai Lama'
    }, {
      text: 'The future belongs to those who believe in the beauty of their dreams.',
      author: 'Eleanor Roosevelt'
    }];
    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    setMoodAnalysis({
      mood: randomMood,
      quote: randomQuote,
      date: new Date(),
      sentimentScore: Math.random() * 10
    });
  };
  const handleSaveEntry = note => {
    const newEntry = {
      id: Date.now(),
      mood: moodAnalysis.mood,
      date: moodAnalysis.date,
      note,
      quote: moodAnalysis.quote,
      sentimentScore: moodAnalysis.sentimentScore
    };
    setEntries([newEntry, ...entries]);
    setShowLogEntry(false);
    setUserInput('');
    setMoodAnalysis(null);
  };
  const handleNewEntry = () => {
    setShowHistory(false);
    setMoodAnalysis(null);
    setUserInput('');
  };
  const handleLogin = () => {
    setIsLoggedIn(true);
    setShowAuth(false);
  };
  return <div className="min-h-screen bg-[#121212] text-white font-['Inter',sans-serif] flex flex-col">
      <Header isLoggedIn={isLoggedIn} onLoginClick={() => setShowAuth(true)} onLogoutClick={() => setIsLoggedIn(false)} />
      <main className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        {!isLoggedIn ? <div className="flex flex-col items-center justify-center h-[70vh]">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-4 bg-gradient-to-r from-teal-400 to-blue-500 bg-clip-text text-transparent">
                Track Your Emotional Journey
              </h2>
              <p className="text-gray-300 max-w-md mx-auto">
                MindMatch helps you understand your emotions with AI analysis,
                personalized quotes, and mood tracking.
              </p>
            </div>
            <button onClick={() => setShowAuth(true)} className="px-6 py-3 bg-gradient-to-r from-teal-500 to-blue-500 rounded-full font-medium hover:opacity-90 transition-all shadow-lg hover:shadow-teal-500/20">
              Get Started
            </button>
          </div> : <>
            {!showHistory ? <div className="space-y-8">
                <MoodInput value={userInput} onChange={setUserInput} onAnalyze={handleAnalyze} />
                {moodAnalysis && <MoodAnalysis analysis={moodAnalysis} onLogEntry={() => setShowLogEntry(true)} onViewHistory={() => setShowHistory(true)} />}
              </div> : <MoodHistory entries={entries} onBack={() => setShowHistory(false)} />}
          </>}
      </main>
      {showLogEntry && <LogEntryModal mood={moodAnalysis.mood} date={moodAnalysis.date} onClose={() => setShowLogEntry(false)} onSave={handleSaveEntry} />}
      {showAuth && <AuthModal onClose={() => setShowAuth(false)} onLogin={handleLogin} />}
      {isLoggedIn && <FloatingActionButton onClick={handleNewEntry} icon={<PlusIcon size={24} />} label="New Entry" />}
    </div>;
}